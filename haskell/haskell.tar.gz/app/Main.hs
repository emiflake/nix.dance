module Main (main) where

main :: IO ()
main = putStrLn "Hello world!"
